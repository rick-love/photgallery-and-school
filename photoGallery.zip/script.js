function album(AlbumName , photolist){
	this.AlbumName=AlbumName,
	this.photolist=photolist
}

album.prototype.addPhoto = function(photo){
	this.photolist.push(photo);
};

album.prototype.showList = function(){
		return this.photolist
};

album.prototype.getPhotoData = function(photo){
		return photo.name + ' ' + photo.location
};

function photo(name, location){
	this.name=name,
	this.location=location

	album.call(this);
};

photo.prototype = Object.create(album.prototype);


var al = new album('Pink', [])

var myPhoto = new photo("Summer vacay rick", "North Jersey");

al.addPhoto(myPhoto);
console.log(al + "this is our album object");
al.showList() //should return all our photos
al.getPhotoData(myPhoto)




