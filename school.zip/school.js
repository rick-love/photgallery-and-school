function person(){
	students
	student.call(this, studentName, grades, hasDetention, hasHomework, skipSchool, giveApple, mood);
	teacher.call(this, teacherName, chgGrades, giveDetention, giveHomework, sendToPrincipal, mood);
}

function teacher(teacherName, chgGrades, giveDetention, giveHomework, sendToPrincipal, teacherMood){
	this.teacherName = teacherName;
	this.chgGrades = chgGrades;
	this.giveDetention = giveDetention;
	this.giveHomework = giveHomework;
	this.sendToPrincipal = sendToPrincipal;
	this.teacherMood = teacherMood;
	student.call(this, studentName, grades, hasDetention, hasHomework, skipSchool, giveApple, studentMood);
}

teacher.prototype.giveDetention = function(studentName){
	if(this.giveDetention == true){
		studentMood === 'Sad' && this.giveApple != true;
	}
	return (this.teacherName + " gave " + this.studentName + " detention. Which made " + this.studentName + " "+ this.studentMood+" .")
}

// teacher.prototype.chgGrades = function(studentName, grades){
// 	this.studentName
// }




function student(studentName, grades, hasDetention, hasHomework, skipSchool, giveApple, studentMood){
	this.studentName = studentName;
	this.grades = grades;
	this.hasDetention = hasDetention;
	this.hasHomework = hasHomework;
	this.skipSchool = skipSchool;
	this.giveApple = giveApple;
	this.studentMood = studentMood;
	teacher.call(this, teacherName, chgGrades, giveDetention, giveHomework, sendToPrincipal, teacherMood)
}


function school(){
	this.isOpen;
	this.isclosed;
}

teacher.prototype = Object.create(person.prototype);
student.prototype = Object.create(person.prototype);

